"""LSTM, GRU and 1D-CNN forecasters. Each outputs 3 values (1h, 3h, 6h) at once."""
import torch.nn as nn


class LSTMNet(nn.Module):
    def __init__(self, n_features, n_out, hidden=64, layers=2, dropout=0.2):
        super().__init__()
        self.rnn = nn.LSTM(n_features, hidden, layers, batch_first=True, dropout=dropout)
        self.head = nn.Sequential(nn.Linear(hidden, 32), nn.ReLU(), nn.Linear(32, n_out))

    def forward(self, x):
        out, _ = self.rnn(x)
        return self.head(out[:, -1])


class GRUNet(nn.Module):
    def __init__(self, n_features, n_out, hidden=64, layers=2, dropout=0.2):
        super().__init__()
        self.rnn = nn.GRU(n_features, hidden, layers, batch_first=True, dropout=dropout)
        self.head = nn.Sequential(nn.Linear(hidden, 32), nn.ReLU(), nn.Linear(32, n_out))

    def forward(self, x):
        out, _ = self.rnn(x)
        return self.head(out[:, -1])


class CNN1DNet(nn.Module):
    """Convolutions slide along the time axis to detect local temporal patterns."""
    def __init__(self, n_features, n_out, channels=64, dropout=0.2):
        super().__init__()
        self.conv = nn.Sequential(
            nn.Conv1d(n_features, channels, 3, padding=1), nn.ReLU(),
            nn.Conv1d(channels, channels, 3, padding=1), nn.ReLU(),
            nn.MaxPool1d(2),
            nn.Conv1d(channels, channels, 3, padding=1), nn.ReLU(),
            nn.AdaptiveAvgPool1d(1))
        self.head = nn.Sequential(nn.Dropout(dropout), nn.Linear(channels, 32), nn.ReLU(), nn.Linear(32, n_out))

    def forward(self, x):                       # x: (batch, time, features)
        return self.head(self.conv(x.transpose(1, 2)).squeeze(-1))


MODELS = {"LSTM": LSTMNet, "GRU": GRUNet, "1D CNN": CNN1DNet}
