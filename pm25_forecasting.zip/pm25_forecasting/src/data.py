"""Data loading: real India air-quality CSV or a realistic synthetic generator.

Real data (recommended for final submission):
  Kaggle "Air Quality Data in India (2015-2020)" -> city_hour.csv
  Put it at data/city_hour.csv and run:  python main.py --city Delhi
  (that file has pollutants but no weather columns; the model simply uses
   whichever of POLLUTANTS / WEATHER columns exist.)

OpenAQ: export one station as hourly CSV with a datetime column and columns
named PM2.5, PM10, NO2, CO, O3 (+ optional temperature, humidity, wind_speed,
pressure) and pass it with --data path.csv.

If no real file is found, a synthetic Delhi-like dataset is generated so the
whole pipeline always runs (it is labelled "synthetic" in all outputs).
"""
from pathlib import Path
import numpy as np
import pandas as pd
from .config import DATA_DIR, POLLUTANTS, WEATHER


def generate_synthetic(n_hours=24 * 365 * 2, seed=0) -> pd.DataFrame:
    """Delhi-like hourly data: traffic peaks, winter smog season, wind dispersion,
    random pollution spikes (crop burning / festivals) and sensor gaps."""
    rng = np.random.default_rng(seed)
    idx = pd.date_range("2022-01-01", periods=n_hours, freq="h")
    hour, doy = idx.hour.values, idx.dayofyear.values

    season = 0.5 + 0.5 * np.cos(2 * np.pi * (doy - 15) / 365)   # high in winter
    temp = 25 - 12 * np.cos(2 * np.pi * (doy - 15) / 365) + 5 * np.sin(2 * np.pi * (hour - 9) / 24) + rng.normal(0, 1, n_hours)
    humidity = np.clip(60 + 15 * np.cos(2 * np.pi * (doy - 200) / 365) - 12 * np.sin(2 * np.pi * (hour - 9) / 24) + rng.normal(0, 5, n_hours), 10, 100)
    pressure = 1008 + 8 * np.cos(2 * np.pi * (doy - 15) / 365) + rng.normal(0, 1.2, n_hours)
    w = np.zeros(n_hours)
    for t in range(1, n_hours):
        w[t] = 0.93 * w[t - 1] + rng.normal(0, 0.35)           # persistent weather systems
    wind = np.clip(2.5 + w + 0.8 * np.sin(2 * np.pi * (hour - 14) / 24), 0.1, None)

    traffic = np.exp(-0.5 * ((hour - 9) / 2) ** 2) + 1.2 * np.exp(-0.5 * ((hour - 20) / 2.5) ** 2)

    log_pm = np.zeros(n_hours)
    base = 3.6 + 1.1 * season
    for t in range(1, n_hours):
        drive = base[t] + 0.35 * traffic[t] - 0.18 * wind[t] + 0.004 * (humidity[t] - 60)
        log_pm[t] = 0.90 * log_pm[t - 1] + 0.10 * drive + rng.normal(0, 0.10)
    pm25 = np.exp(log_pm)
    for s in rng.choice(n_hours - 48, n_hours // (24 * 12), replace=False):   # sudden spikes
        mag, dur = rng.uniform(80, 250), int(rng.integers(8, 30))
        pm25[s:s + dur] += mag * np.exp(-np.arange(dur) / (dur / 2.5))
    pm25 = np.clip(pm25, 3, 900)

    df = pd.DataFrame({
        "datetime": idx, "PM2.5": pm25,
        "PM10": pm25 * rng.uniform(1.4, 1.9, n_hours) + rng.normal(0, 8, n_hours),
        "NO2": np.clip(25 + 0.12 * pm25 + 15 * traffic + rng.normal(0, 6, n_hours), 2, None),
        "CO": np.clip(0.6 + 0.004 * pm25 + 0.5 * traffic + rng.normal(0, 0.15, n_hours), 0.1, None),
        "O3": np.clip(30 + 25 * np.sin(2 * np.pi * (hour - 8) / 24).clip(0) - 0.05 * pm25 + rng.normal(0, 5, n_hours), 1, None),
        "temperature": temp, "humidity": humidity, "wind_speed": wind, "pressure": pressure})
    df["PM10"] = df["PM10"].clip(lower=5)
    for c in POLLUTANTS + WEATHER:                       # random sensor drop-outs
        df.loc[rng.random(n_hours) < 0.03, c] = np.nan
    for _ in range(12):                                   # long outages
        s = int(rng.integers(0, n_hours - 100))
        df.loc[s:s + int(rng.integers(6, 60)), rng.choice(POLLUTANTS + WEATHER)] = np.nan
    return df


def load_dataset(path=None, city="Delhi"):
    """Return (hourly DataFrame indexed by datetime, source label)."""
    p = Path(path) if path else DATA_DIR / "city_hour.csv"
    if p.exists():
        try:
            raw = pd.read_csv(p)
            tcol = next(c for c in raw.columns if c.lower() in ("datetime", "date", "timestamp", "date.utc", "utc"))
            raw[tcol] = pd.to_datetime(raw[tcol], errors="coerce")
            if "City" in raw.columns and city:
                raw = raw[raw["City"] == city]
            raw = raw.rename(columns={tcol: "datetime"}).dropna(subset=["datetime"])
            raw = raw.sort_values("datetime").drop_duplicates("datetime").set_index("datetime")
            raw.index = raw.index.tz_localize(None) if raw.index.tz is not None else raw.index
            keep = [c for c in POLLUTANTS + WEATHER if c in raw.columns]
            df = raw[keep].asfreq("h")
            df = df[df["PM2.5"].first_valid_index():]          # start where PM2.5 starts
            return df, f"real: {p.name} ({city})"
        except Exception as e:
            print(f"[warn] could not load real data ({e}); using synthetic.")
    return generate_synthetic().set_index("datetime"), "synthetic (Delhi-like)"
