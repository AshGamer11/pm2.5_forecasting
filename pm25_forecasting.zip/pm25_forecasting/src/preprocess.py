"""Missing-value handling, feature engineering, windowing, chronological split."""
import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler
from .config import WINDOW, HORIZONS, TARGET, TRAIN_FRAC, VAL_FRAC


def clean(df: pd.DataFrame, max_gap=6):
    """Handle missing readings.
    1. Keep a 0/1 'PM2.5 was missing' flag so the model knows which values were imputed.
    2. Short gaps (<= max_gap h): time-based linear interpolation.
    3. Longer gaps: forward/backward fill, then column median (rare)."""
    df = df.copy()
    report = df.isna().sum()
    flag = df[TARGET].isna().astype(float)
    df = df.interpolate(method="time", limit=max_gap, limit_direction="both")
    df = df.ffill().bfill().fillna(df.median())
    df[f"{TARGET}_missing"] = flag
    return df, report


def add_time_features(df):
    h, d = df.index.hour.values, df.index.dayofyear.values
    df["hour_sin"], df["hour_cos"] = np.sin(2 * np.pi * h / 24), np.cos(2 * np.pi * h / 24)
    df["doy_sin"], df["doy_cos"] = np.sin(2 * np.pi * d / 365), np.cos(2 * np.pi * d / 365)
    return df


def build_windows(features, target, window, horizons):
    """X[i] = features[i : i+window];  y[i, k] = target[i + window - 1 + horizons[k]]."""
    n = len(features) - window - max(horizons) + 1
    X = np.stack([features[i:i + window] for i in range(n)]).astype(np.float32)
    y = np.stack([[target[i + window - 1 + h] for h in horizons] for i in range(n)]).astype(np.float32)
    return X, y


def prepare(df, window=WINDOW, horizons=HORIZONS):
    """Full preprocessing -> dict of arrays.

    * log1p on skewed pollutants (tames spikes); target is log1p(PM2.5), standardised.
    * Scalers fit on the TRAIN segment only (no leakage).
    * Chronological split 70/15/15 with no target-time overlap between splits.
    """
    df, report = clean(df)
    df = add_time_features(df)
    for c in ["PM2.5", "PM10", "NO2", "CO"]:
        if c in df.columns:
            df[c] = np.log1p(df[c])
    cols = list(df.columns)
    n = len(df)
    n_tr, n_va = int(n * TRAIN_FRAC), int(n * VAL_FRAC)

    scaler = StandardScaler().fit(df.iloc[:n_tr].values)
    scaled = scaler.transform(df.values)
    tl = df[TARGET].values
    t_mean, t_std = tl[:n_tr].mean(), tl[:n_tr].std()
    t_scaled = (tl - t_mean) / t_std

    X, y = build_windows(scaled, t_scaled, window, horizons)
    last_in = np.arange(len(X)) + window - 1          # time index of the newest input hour
    mh = max(horizons)
    tr = last_in + mh < n_tr
    va = (last_in >= n_tr) & (last_in + mh < n_tr + n_va)
    te = last_in >= n_tr + n_va
    return {"X_train": X[tr], "y_train": y[tr], "X_val": X[va], "y_val": y[va],
            "X_test": X[te], "y_test": y[te], "t_mean": t_mean, "t_std": t_std,
            "features": cols, "missing_report": report}


def to_ugm3(y_scaled, t_mean, t_std):
    """Undo standardisation and log1p -> PM2.5 in µg/m³."""
    return np.expm1(np.asarray(y_scaled) * t_std + t_mean)
