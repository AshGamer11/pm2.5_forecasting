"""Training loop: Huber loss (robust to spikes), LR scheduling, early stopping."""
import copy
import torch
import torch.nn as nn
from torch.utils.data import DataLoader, TensorDataset
from .config import BATCH_SIZE, EPOCHS, LR, PATIENCE


def fit(model, data, device="cpu", epochs=EPOCHS, verbose=True, name=""):
    loader = DataLoader(TensorDataset(torch.tensor(data["X_train"]), torch.tensor(data["y_train"])),
                        batch_size=BATCH_SIZE, shuffle=True)
    Xv, yv = torch.tensor(data["X_val"]).to(device), torch.tensor(data["y_val"]).to(device)
    model.to(device)
    opt = torch.optim.Adam(model.parameters(), lr=LR)
    sched = torch.optim.lr_scheduler.ReduceLROnPlateau(opt, factor=0.5, patience=2)
    loss_fn = nn.HuberLoss(delta=1.0)
    best, best_state, bad, hist = float("inf"), None, 0, {"train": [], "val": []}
    for ep in range(1, epochs + 1):
        model.train(); tl = 0.0
        for xb, yb in loader:
            xb, yb = xb.to(device), yb.to(device)
            opt.zero_grad(); loss = loss_fn(model(xb), yb); loss.backward()
            nn.utils.clip_grad_norm_(model.parameters(), 1.0); opt.step()
            tl += loss.item() * len(xb)
        tl /= len(loader.dataset)
        model.eval()
        with torch.no_grad():
            vl = loss_fn(model(Xv), yv).item()
        sched.step(vl); hist["train"].append(tl); hist["val"].append(vl)
        if vl < best - 1e-5:
            best, best_state, bad = vl, copy.deepcopy(model.state_dict()), 0
        else:
            bad += 1
        if verbose and (ep % 5 == 0 or ep == 1):
            print(f"  [{name}] epoch {ep:02d}  train {tl:.4f}  val {vl:.4f}")
        if bad >= PATIENCE:
            if verbose: print(f"  [{name}] early stop at epoch {ep}")
            break
    model.load_state_dict(best_state)
    return model, hist


@torch.no_grad()
def predict(model, X, device="cpu"):
    model.eval().to(device)
    return model(torch.tensor(X).to(device)).cpu().numpy()
