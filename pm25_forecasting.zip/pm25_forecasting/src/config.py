"""Central configuration for the PM2.5 forecasting project."""
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DATA_DIR = ROOT / "data"
RESULTS_DIR = ROOT / "results"

WINDOW = 24                 # hours of history fed to the model
HORIZONS = [1, 3, 6]        # forecast horizons (hours ahead)
TARGET = "PM2.5"

# Chronological split (no shuffling -> no leakage from the future)
TRAIN_FRAC, VAL_FRAC = 0.70, 0.15   # remaining 0.15 = test

BATCH_SIZE = 128
EPOCHS = 40
LR = 1e-3
PATIENCE = 6                # early stopping
SEED = 42

POLLUTANTS = ["PM2.5", "PM10", "NO2", "CO", "O3"]
WEATHER = ["temperature", "humidity", "wind_speed", "pressure"]
